# A simple Python program
def main():
    print("My name is Chioma")
    print("This is my first Python program for the assignment.")
    print("Learning Python one step at a time!")
    
if __name__ == "__main__":
    main()
